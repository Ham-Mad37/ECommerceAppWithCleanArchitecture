import {
  useEffect,
  useState,
} from "react";

import {
  Link,
  useParams,
} from "react-router-dom";

import {
  ArrowLeft,
  CheckCircle2,
  Loader2,
  Package,
  ShoppingBag,
} from "lucide-react";

import { orderService } from "../../services/orderService";

import type {
  Order,
} from "../../types/order";

export default function OrderDetailsPage() {
  const { orderId } = useParams();

  const [order, setOrder] =
    useState<Order | null>(null);

  const [loading, setLoading] =
    useState(true);

  const [error, setError] =
    useState("");

  useEffect(() => {
    const loadOrder = async () => {
      try {
        setLoading(true);
        setError("");

        if (!orderId) {
          throw new Error(
            "Order ID is missing."
          );
        }

        const data =
          await orderService.getOrderById(
            Number(orderId)
          );

        setOrder(data);

      } catch (error: any) {
        const message =
          error?.response?.data?.detail ??
          error?.response?.data?.message ??
          error?.response?.data?.title ??
          error?.message ??
          "Unable to load order.";

        setError(message);

      } finally {
        setLoading(false);
      }
    };

    loadOrder();
  }, [orderId]);

  if (loading) {
    return (
      <div className="flex min-h-[70vh] items-center justify-center">
        <div className="flex flex-col items-center gap-3 text-slate-500">

          <Loader2
            size={34}
            className="animate-spin"
          />

          <p className="text-sm">
            Loading order...
          </p>

        </div>
      </div>
    );
  }

  if (error || !order) {
    return (
      <div className="mx-auto flex min-h-[70vh] max-w-3xl flex-col items-center justify-center px-4 text-center">

        <div className="flex h-20 w-20 items-center justify-center rounded-full bg-red-50">
          <Package
            size={34}
            className="text-red-500"
          />
        </div>

        <h1 className="mt-6 text-2xl font-bold text-slate-900">
          Order not found
        </h1>

        <p className="mt-2 text-slate-500">
          {error ||
            "We couldn't find this order."}
        </p>

        <Link
          to="/orders"
          className="mt-6 rounded-xl bg-slate-900 px-6 py-3 text-sm font-semibold text-white hover:bg-slate-800"
        >
          My Orders
        </Link>

      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 sm:py-12 lg:px-8">

      {/* Header */}

      <Link
        to="/orders"
        className="mb-6 inline-flex items-center gap-2 text-sm font-medium text-slate-500 hover:text-slate-900"
      >
        <ArrowLeft size={17} />

        My Orders
      </Link>

      {/* Success */}

      <div className="mb-8 rounded-2xl border border-green-200 bg-green-50 p-6">

        <div className="flex items-start gap-4">

          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-green-100">

            <CheckCircle2
              size={26}
              className="text-green-600"
            />

          </div>

          <div>

            <h1 className="text-2xl font-bold text-slate-900">
              Order #{order.id}
            </h1>

            <p className="mt-1 text-sm text-slate-600">
              Your order has been successfully created.
            </p>

          </div>

        </div>

      </div>

      {/* Order information */}

      <div className="grid gap-8 lg:grid-cols-[1fr_340px]">

        {/* Items */}

        <div>

          <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">

            <div className="border-b border-slate-200 px-5 py-4 sm:px-6">

              <h2 className="font-semibold text-slate-900">
                Order Items
              </h2>

            </div>

            <div className="divide-y divide-slate-200">

              {order.items.map(
                (item, index) => (
                  <div
                    key={`${item.productId}-${index}`}
                    className="flex gap-4 p-5 sm:p-6"
                  >

                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-slate-100">

                      <ShoppingBag
                        size={22}
                        className="text-slate-400"
                      />

                    </div>

                    <div className="min-w-0 flex-1">

                      <h3 className="font-semibold text-slate-900">
                        {item.productName}
                      </h3>

                      <p className="mt-1 text-sm text-slate-500">
                        ${item.unitPrice.toFixed(2)}
                        {" "}×{" "}
                        {item.quantity}
                      </p>

                    </div>

                    <div className="shrink-0 font-semibold text-slate-900">
                      $
                      {item.lineTotal.toFixed(
                        2
                      )}
                    </div>

                  </div>
                )
              )}

            </div>

          </div>

        </div>

        {/* Summary */}

        <div className="h-fit rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">

          <h2 className="text-lg font-semibold text-slate-900">
            Order Summary
          </h2>

          <div className="mt-6 space-y-4">

            <div className="flex justify-between text-sm">

              <span className="text-slate-500">
                Subtotal
              </span>

              <span className="font-medium">
                $
                {(
                  order.totalAmount -
                  order.shippingCost +
                  order.discount
                ).toFixed(2)}
              </span>

            </div>

            <div className="flex justify-between text-sm">

              <span className="text-slate-500">
                Shipping
              </span>

              <span className="font-medium">
                $
                {order.shippingCost.toFixed(
                  2
                )}
              </span>

            </div>

            {order.discount > 0 && (
              <div className="flex justify-between text-sm">

                <span className="text-slate-500">
                  Discount
                </span>

                <span className="font-medium text-green-600">
                  -$
                  {order.discount.toFixed(
                    2
                  )}
                </span>

              </div>
            )}

            <div className="h-px bg-slate-200" />

            <div className="flex items-center justify-between">

              <span className="font-semibold text-slate-900">
                Total
              </span>

              <span className="text-2xl font-bold text-slate-900">
                $
                {order.totalAmount.toFixed(
                  2
                )}
              </span>

            </div>

          </div>

          {/* Status */}

          <div className="mt-6 rounded-xl bg-slate-50 p-4">

            <p className="text-xs font-medium uppercase tracking-wide text-slate-400">
              Order Status
            </p>

            <p className="mt-1 font-semibold text-slate-900">
              {order.status}
            </p>

          </div>

        </div>

      </div>

    </div>
  );
}